#include "scribe_log_handler.h"

#include <string>
#include <iostream>
#include <boost/shared_ptr.hpp>
#include <thrift/protocol/TBinaryProtocol.h>
#include <thrift/transport/TSocket.h>
#include <thrift/transport/TTransportUtils.h>

using namespace apache::thrift;
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;

#include "gen-cpp/scribe.h"

using namespace scribe::thrift;

namespace lspf {
namespace log {

std::string ScribeLogHandler::service_address = "";
int ScribeLogHandler::service_port = 0;
const unsigned int MAX_LOG_SIZE = 32;

std::vector<LogEntry> ScribeLogHandler::messages;
std::vector<LogEntry> ScribeLogHandler::err_messages;

BlockingQueue<LogEntry> ScribeLogHandler::msg_queue;
BlockingQueue<LogEntry> ScribeLogHandler::err_msg_queue;

void ScribeLogHandler::AddLog(const std::string &category, const std::string &buff)
{
    LogEntry LogEntry_;
    LogEntry_.category.assign(category);
    LogEntry_.message.assign(buff);
    msg_queue.PushFront(LogEntry_);
}

void ScribeLogHandler::AddErrorLog(const std::string &category, const std::string &buff)
{
    LogEntry errLogEntry_;
    errLogEntry_.category.assign(category);
    errLogEntry_.message.assign(buff);
    err_msg_queue.PushFront(errLogEntry_);
}

void ScribeLogHandler::WriteLog()
{
    boost::shared_ptr<TTransport> socket(new TSocket(service_address, service_port));
    boost::shared_ptr<TTransport> transport(new TFramedTransport(socket));
    boost::shared_ptr<TProtocol> protocol(new TBinaryProtocol(transport));
    boost::shared_ptr<scribeClient> client(new scribeClient(protocol));

    while(1){
        try{
            transport->open();
            if(transport->isOpen()){
                WriteLogHandle(client.get());
            }else{
                sleep(5);
            }

            transport->close();
        }catch (TException& tx) {
            //cout << "ERROR: " << tx.what() << endl;
            //PLOG_FATAL(tx.what());
            continue;
        }
    }
}

int ScribeLogHandler::WriteLogHandle(scribeClient *client)
{
    try{
        int ret = 0;
        while(true){
            for (size_t i=0; i<MAX_LOG_SIZE && messages.size()<MAX_LOG_SIZE; i++){
                LogEntry LogEntry_;

                if (!msg_queue.TryPopBack(&LogEntry_)){
                    break;
                }else{
                    messages.push_back(LogEntry_);
                }
            }

            if (messages.size() == 0){
                usleep(1000);
                continue;
            }

            ret = client->Log(messages);
            if (ret == ResultCode::TRY_LATER){
                //PLOG_FATAL("WriteLog Error");
                continue;
            }
            messages.clear();

            while (err_messages.size() < MAX_LOG_SIZE){
                LogEntry LogEntry_;

                if (err_msg_queue.TimedPopBack(&LogEntry_, 1)){
                    break;
                }else{
                    err_messages.push_back(LogEntry_);
                }
            }

            if (err_messages.size() == 0){
                continue;
            }

            ret = client->Log(err_messages);
            if (ret == ResultCode::TRY_LATER){
                //PLOG_FATAL("WriteLog Error");
                continue;
            }

            err_messages.clear();
        }
    }catch (TException& tx) {
        //cout << "ERROR: " << tx.what() << endl;
        //PLOG_FATAL(tx.what());
        return -1;
    }
	return 0;
}

} // namespace sclog
} // namespace lspf
